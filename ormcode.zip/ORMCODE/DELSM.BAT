del BEXM\ORM\*.SYM
